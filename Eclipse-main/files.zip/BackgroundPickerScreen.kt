package com.eclipse.browser.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.eclipse.browser.ui.components.EclipseEnterAnimation
import com.eclipse.browser.ui.theme.*
import java.io.File

// Section 14: Dedicated separate screen for background customization
// Section 15: Image → Static/Animate toggle | Video → no toggle (always animated)
// Section 16: Cropping UI with light overlay indicators
// Section 17: Custom bg disables default theme color on background

@Composable
fun BackgroundPickerScreen(
    currentBgType: String,  // "none", "preset", "image", "video"
    currentBgPath: String,
    accentColor: Color,
    onSave: (type: String, path: String, animate: Boolean) -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedMime by remember { mutableStateOf("") }
    var isAnimated by remember { mutableStateOf(false) }
    var showCropPreview by remember { mutableStateOf(false) }

    // Section 15: Image picker — accepts images and videos
    val pickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            pickedUri = it
            val mime = context.contentResolver.getType(it) ?: ""
            pickedMime = mime
            showCropPreview = true
            // Section 15: Video auto-animated — no toggle shown
            isAnimated = mime.startsWith("video/")
        }
    }

    Column(modifier = modifier.fillMaxSize()) {

        // ── HEADER ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF08080F))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(38.dp).clip(CircleShape)
                    .background(EclipseSurface).clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Text("←", color = TextPrimary, fontSize = 18.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = "Custom Background",
                    fontFamily = Outfit, fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp, color = TextPrimary
                )
                Text(
                    text = "Upload your own image or video",
                    fontFamily = SpaceMono, fontSize = 9.sp, color = TextMuted2, letterSpacing = 1.sp
                )
            }
        }

        Box(Modifier.fillMaxWidth().height(1.dp).background(EclipseBorder))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ── CURRENT STATUS ──
            EclipseEnterAnimation(index = 0) {
                if (currentBgType == "image" || currentBgType == "video") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(EclipseSurface)
                            .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    ) {
                        if (currentBgPath.isNotBlank()) {
                            AsyncImage(
                                model = currentBgPath,
                                contentDescription = "Current background",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        // Section 17 notice
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "✓ Custom background active — theme color applies to text/icons only",
                                fontFamily = SpaceMono, fontSize = 8.sp,
                                color = accentColor, letterSpacing = 0.5.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // ── UPLOAD BUTTON ──
            EclipseEnterAnimation(index = 1) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(EclipseSurface)
                        .border(1.dp, EclipseBorder, RoundedCornerShape(16.dp))
                        .clickable { pickerLauncher.launch("*/*") }
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📷", fontSize = 32.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Choose Image or Video",
                            fontFamily = Outfit, fontWeight = FontWeight.Medium,
                            fontSize = 15.sp, color = TextPrimary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "JPG, PNG, WEBP, MP4, MKV supported",
                            fontFamily = Outfit, fontSize = 12.sp, color = TextMuted
                        )
                    }
                }
            }

            // ── PICKED IMAGE PREVIEW + CROP ──
            AnimatedVisibility(
                visible = showCropPreview && pickedUri != null,
                enter = fadeIn() + slideInVertically(initialOffsetY = { 40 }),
                exit = fadeOut()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

                    // Section 16: Cropping UI with light overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black)
                    ) {
                        AsyncImage(
                            model = pickedUri,
                            contentDescription = "Background preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )

                        // Section 16: Very faint top bar indicator
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp)
                                .align(Alignment.TopCenter)
                                .background(Color.Black.copy(alpha = 0.25f))
                        ) {
                            Text(
                                text = "Top bar area",
                                fontFamily = SpaceMono, fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }

                        // Section 16: Very faint bottom bar indicator
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp)
                                .align(Alignment.BottomCenter)
                                .background(Color.Black.copy(alpha = 0.25f))
                        ) {
                            Text(
                                text = "Bottom nav area",
                                fontFamily = SpaceMono, fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }

                        // Visible area label
                        Box(
                            modifier = Modifier.align(Alignment.Center)
                        ) {
                            Text(
                                text = "Visible area",
                                fontFamily = SpaceMono, fontSize = 8.sp,
                                color = Color.White.copy(alpha = 0.5f),
                                letterSpacing = 2.sp
                            )
                        }
                    }

                    // Section 15: Static/Animate toggle — only for images, NOT videos
                    if (!pickedMime.startsWith("video/")) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(EclipseSurface)
                                .border(1.dp, EclipseBorder, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text(
                                    text = "Background Mode",
                                    fontFamily = SpaceMono, fontSize = 9.sp,
                                    letterSpacing = 2.sp, color = TextMuted2
                                )
                                Spacer(Modifier.height(12.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    // Section 15: Static option
                                    ModeButton(
                                        label = "Static",
                                        icon = "🖼",
                                        desc = "Still image",
                                        isSelected = !isAnimated,
                                        accentColor = accentColor,
                                        onClick = { isAnimated = false }
                                    )
                                    // Section 15: Animate option
                                    ModeButton(
                                        label = "Animate",
                                        icon = "✨",
                                        desc = "AI animates image",
                                        isSelected = isAnimated,
                                        accentColor = accentColor,
                                        onClick = { isAnimated = true }
                                    )
                                }
                            }
                        }
                    } else {
                        // Section 15: Video — always animated, no toggle needed
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(accentColor.copy(alpha = 0.07f))
                                .border(1.dp, accentColor.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Text(
                                text = "✨ Video backgrounds are automatically animated",
                                fontFamily = Outfit, fontSize = 12.sp, color = accentColor
                            )
                        }
                    }

                    // ── APPLY BUTTON ──
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(100.dp))
                            .background(accentColor)
                            .clickable {
                                val type = if (pickedMime.startsWith("video/")) "video" else "image"
                                val path = pickedUri?.toString() ?: ""
                                onSave(type, path, isAnimated)
                            }
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Apply Background",
                            fontFamily = SpaceMono, fontSize = 11.sp,
                            letterSpacing = 2.sp, color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // ── CLEAR BUTTON (if custom bg active) ──
            if (currentBgType == "image" || currentBgType == "video") {
                EclipseEnterAnimation(index = 3) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(100.dp))
                            .background(EclipseSurface)
                            .border(1.dp, EclipseBorder, RoundedCornerShape(100.dp))
                            .clickable { onClear() }
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Remove Custom Background",
                            fontFamily = SpaceMono, fontSize = 10.sp,
                            letterSpacing = 1.sp, color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeButton(
    label: String,
    icon: String,
    desc: String,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) accentColor.copy(alpha = 0.12f) else EclipseSurface2)
            .border(
                1.dp,
                if (isSelected) accentColor.copy(alpha = 0.4f) else EclipseBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                fontFamily = Outfit, fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
                color = if (isSelected) accentColor else TextPrimary
            )
            Text(
                text = desc,
                fontFamily = Outfit, fontSize = 10.sp,
                color = TextMuted2, textAlign = TextAlign.Center
            )
        }
    }
}
